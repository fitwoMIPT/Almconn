from django.db import models
from django.contrib.auth.models import User
from PIL import Image
# Create your models here.


class Profile(models.Model):
    TEXT_C = [
        ("Математика", "Математика"),
        ("История", "История")
    ]
    GENDER_C = [
        ("Мужской", "Мужской"),
        ("Женский", "Женский"),
        ("Другой", "Другой")
    ]
    OS_C = [
        ("Естественные науки", "Естественные науки"),
        ("Гуманитарные науки", "Гуманитарные науки"),
        ("Другое", "Другое")
    ]
    SPACES_C = [
        ("Очно", "Очно"),
        ("Дистант", "Дистант")
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    full_name = models.CharField(max_length=100, null=True)
    age = models.IntegerField(null=True)
    gender = models.CharField(
        max_length=50, blank=True, null=True, choices=GENDER_C)
    profile_image = models.ImageField(
        upload_to='profile_pic', default="default.jpg", null=True, blank=True)
    bio = models.TextField(null=True)
    tech_stack = models.CharField(max_length=500, null=True)

    editor = models.CharField(
        max_length=25, choices=TEXT_C, default=None, null=True, blank=True)
    os = models.CharField(
        max_length=20, choices=OS_C, default=None, null=True, blank=True)
    spacing = models.CharField(
        max_length=20, choices=SPACES_C, default=None, null=True, blank=True)

    likeability = models.ManyToManyField(
        User, related_name="likes", blank=True)
    blocked_by = models.ManyToManyField(
        User, related_name="blocked", blank=True)

    def __str__(self):
        return f"{self.full_name} Профиль"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)

        img = Image.open(self.profile_image.path)

        if img.height > 200 or img.width > 200:
            output_size = (250, 250)
            img.thumbnail(output_size)
            img.save(self.profile_image.path)

    @property
    def num_likes(self):
        return self.likeability.all().count()
